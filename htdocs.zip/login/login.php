﻿<?php 
session_start(); 
// if (isset($_SESSION['kakao_nickname'])) {
//     header('Location: ./index.php');
//     exit();
// }
?>
<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8"/>
   <title>Kakao 지도 시작하기</title>
   <link rel="stylesheet" type="text/css" href="./css/style.css">
   <link rel="stylesheet" type="text/css" href="./css/theme.css">
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
   <script src="https://developers.kakao.com/sdk/js/kakao.js"></script>
</head>
<body>
    <div class="page-loader"></div>
    <section class="login_section">
        <div class="login_wrap">
            <form class="login_box" action="login_process.php" method="POST">
                <ul class="login_top">
                    <li>
                        <input type="text" name="id" placeholder="아이디" required>
                    </li>
                    <li>
                        <input type="password" name="pw" placeholder="비밀번호" required>
                    </li>
                </ul>
                <div class="login_bottom">
                    <div class="login_btn">
                        <input type="submit" name="" value="로그인">
                    </div>
                    <div class="login_footer">
                        <p><a href="./join.php">회원가입</a></p>
                    </div>
                </div>
            </form>
        </div>
    </section>
   <!-- <div class="page-loader">
      <div class="page_logo">
         <img src="./images/logo.svg">
      </div>
   </div> -->
   <section class="login_section">
      <div class="login_wrap">
         
      </div>
   </section>
   <ul>
   <li onclick="kakaoLogin();">
      <a href="javascript:void(0)">
          <span>카카오 로그인</span>
      </a>
   </li>
   <li onclick="kakaoLogout();">
      <a href="javascript:void(0)">
          <span>카카오 로그아웃</span>
      </a>
   </li>
</ul>
<!-- 카카오 스크립트 -->
<script src="https://developers.kakao.com/sdk/js/kakao.js"></script>
<script>
Kakao.init('0e2d971d60a7f8f8cfb27620fb24d4b5'); //발급받은 키 중 javascript키를 사용해준다.
console.log(Kakao.isInitialized()); // sdk초기화여부판단
let responseData;
//카카오로그인
function kakaoLogin() {
    Kakao.Auth.login({
      success: function (response) {
        Kakao.API.request({
          url: '/v2/user/me',
          success: function (response) {
             responseData = response;
             saveToDatabase(responseData);
           // location.href = "./index.php";
          },
          fail: function (error) {
            console.log(error)
          },
        })
      },
      fail: function (error) {
        console.log(error)
      },
    })
  }
//카카오로그아웃  
function kakaoLogout() {
    if (Kakao.Auth.getAccessToken()) {
      Kakao.API.request({
        url: '/v1/user/unlink',
        success: function (response) {
           console.log(response)
        },
        fail: function (error) {
          console.log(error)
        },
      })
      Kakao.Auth.setAccessToken(undefined)
    }
  }  

function saveToDatabase(responseData) {
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "saveToDatabase.php", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log(xhr.responseText);
        }
    };
    let data = JSON.stringify(responseData);
    document.write(data);
    xhr.send(data);
}
</script>
</script>
<div id="response"></div>
</body>
<script src="js/jquery.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/jquery.bootstrap.js"></script>
    <script src="js/jquery.magnific-popup.js"></script>
    <script src="js/jquery.owl.carousel.js"></script>
    <script src="js/main.js"></script>
</html>
</body>
</html>